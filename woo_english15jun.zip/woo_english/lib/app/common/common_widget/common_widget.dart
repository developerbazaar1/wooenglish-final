import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/common/common_text_styles/common_text_styles.dart';
import 'package:woo_english/app/theme/colors/colors.dart';
import 'package:woo_english/app/theme/constants/constants.dart';
import 'package:woo_english/read_more/read_more.dart';

class CW {
  ///For Full Size Use In Column Not In ROW
  static Widget commonElevatedButton({double? height,
    double? width,
    EdgeInsetsGeometry? buttonMargin,
    EdgeInsetsGeometry? contentPadding,
    double? borderRadius,
    Color? splashColor,
    bool wantContentSizeButton = true,
    Color? buttonColor,
    double? elevation,
    required VoidCallback onPressed,
    required Widget child}) {
    return Container(
      height: wantContentSizeButton ? height : 54.px,
      width: wantContentSizeButton ? width : double.infinity,
      margin: buttonMargin,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius ?? C.buttonRadius),
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          elevation: elevation ?? 0.px,
          padding: contentPadding,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(borderRadius ?? C.buttonRadius),
          ),
          backgroundColor: buttonColor ?? Col.primary,
          foregroundColor: splashColor ?? Colors.white12,
          shadowColor: Colors.transparent,
        ),
        child: child,
      ),
    );
  }


  static Widget commonRefreshIndicator({required Widget child,required  RefreshCallback onRefresh})
  {
    return RefreshIndicator(onRefresh: onRefresh, child: child);
  }

  static Widget commonElevatedButtonForLoginSignUp({double? height,
    double? width,
    bool isClicked = false,
    EdgeInsetsGeometry? buttonMargin,
    EdgeInsetsGeometry? contentPadding,
    double? borderRadius,
    Color? splashColor,
    bool wantContentSizeButton = true,
    Color? buttonColor,
    double? elevation,
    required VoidCallback onPressed,
    required Widget child}) {
    return AnimatedContainer(
      height: isClicked ? 52.px : height,
      width: isClicked ? 52.px : width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
            isClicked ? 30.px : borderRadius ?? C.buttonRadius),
        color: buttonColor,
      ),
      duration: const Duration(
        seconds: 2,
      ),
      child: isClicked
          ? SizedBox(
        height: height ?? 52.px,
        width: height ?? 52.px,
        child: Padding(
          padding: EdgeInsets.all(10.px),
          child: CircularProgressIndicator(
            backgroundColor: const Color(0xff7C7C7C).withOpacity(.5),
            strokeWidth: 3,
          ),
        ),
      )
          : Container(
        height: wantContentSizeButton ? height : 54.px,
        width: wantContentSizeButton ? width : double.infinity,
        margin: buttonMargin,
        decoration: BoxDecoration(
          borderRadius:
          BorderRadius.circular(borderRadius ?? C.buttonRadius),
        ),
        child: ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            elevation: elevation ?? 0.px,
            padding: contentPadding,
            shape: RoundedRectangleBorder(
              borderRadius:
              BorderRadius.circular(borderRadius ?? C.buttonRadius),
            ),
            backgroundColor: buttonColor ?? Col.primary,
            foregroundColor: splashColor ?? Colors.white12,
            shadowColor: Colors.transparent,
          ),
          child: child,
        ),
      ),
    );
  }

  static Widget commonTextButton({double? height,
    double? width,
    EdgeInsetsGeometry? buttonMargin,
    EdgeInsetsGeometry? contentPadding,
    double? borderRadius,
    bool wantContentSizeButton = true,
    double? elevation,
    required VoidCallback onPressed,
    required Widget child}) {
    return Container(
      height: height,
      width: wantContentSizeButton ? width : double.infinity,
      margin: buttonMargin,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius ?? C.textButtonRadius),
      ),
      child: TextButton(
        onPressed: onPressed,
        style: TextButton.styleFrom(
          elevation: elevation ?? 0.px,
          padding: contentPadding,
          shape: RoundedRectangleBorder(
            borderRadius:
            BorderRadius.circular(borderRadius ?? C.textButtonRadius),
          ),
          backgroundColor: Colors.transparent,
          foregroundColor: Col.primary,
          shadowColor: Colors.transparent,
        ),
        child: child,
      ),
    );
  }

  static Widget commonTextFieldForLoginSignUP({
    double? elevation,
    String? hintText,
    EdgeInsetsGeometry? contentPadding,
    TextEditingController? controller,
    int? maxLines,
    double? cursorHeight,
    bool wantBorder = true,
    ValueChanged<String>? onChanged,
    FormFieldValidator<String>? validator,
    Color? fillColor,
    Color? initialBorderColor,
    double? initialBorderWidth,
    TextInputType? keyboardType,
    double? borderRadius,
    double? maxHeight,
    TextStyle? hintStyle,
    TextStyle? style,
    List<TextInputFormatter>? inputFormatters,
    TextCapitalization textCapitalization = TextCapitalization.none,
    bool autofocus = false,
    bool readOnly = false,
  }) {
    return TextFormField(
      cursorHeight: cursorHeight,
      controller: controller,
      onChanged: onChanged ??
              (value) {
            value = value.trim();
            if (value.isEmpty || value
                .replaceAll(" ", "")
                .isEmpty) {
              controller?.text = "";
            }
          },
      validator: validator,
      keyboardType: keyboardType ?? TextInputType.streetAddress,
      readOnly: readOnly,
      autofocus: autofocus,
      inputFormatters: inputFormatters,
      textCapitalization: textCapitalization,
      style: style ??
          Theme
              .of(Get.context!)
              .textTheme
              .bodyMedium
              ?.copyWith(fontFamily: C.fontOpenSans, color: Col.onSecondary),
      decoration: InputDecoration(
        hintText: hintText,
        fillColor: fillColor ?? Col.inverseSecondary,
        filled: true,
        contentPadding:
        contentPadding ?? EdgeInsets.symmetric(horizontal: 20.px),
        hintStyle: hintStyle ??
            Theme
                .of(Get.context!)
                .textTheme
                .bodyMedium
                ?.copyWith(fontFamily: C.fontOpenSans, color: Col.onSecondary),
        disabledBorder: OutlineInputBorder(
            borderSide: wantBorder
                ? BorderSide(color: Col.inverseSecondary, width: 2.px)
                : BorderSide.none,
            borderRadius:
            BorderRadius.circular(borderRadius ?? C.loginTextFieldRadius)),
        border: OutlineInputBorder(
            borderSide: wantBorder
                ? BorderSide(color: Col.primary, width: 2.px)
                : BorderSide.none,
            borderRadius:
            BorderRadius.circular(borderRadius ?? C.loginTextFieldRadius)),
        enabledBorder: OutlineInputBorder(
            borderSide: wantBorder
                ? BorderSide(
                color: initialBorderColor ?? Col.inverseSecondary,
                width: initialBorderWidth ?? 2.px)
                : BorderSide.none,
            borderRadius:
            BorderRadius.circular(borderRadius ?? C.loginTextFieldRadius)),
        errorBorder: OutlineInputBorder(
            borderSide: wantBorder
                ? BorderSide(color: Col.error, width: 2.px)
                : BorderSide.none,
            borderRadius:
            BorderRadius.circular(borderRadius ?? C.loginTextFieldRadius)),
      ),
    );
  }

  static Widget commonTextFieldForWriteSomething({
    double? elevation,
    String? hintText,
    EdgeInsetsGeometry? contentPadding,
    TextEditingController? controller,
    int? maxLines,
    double? cursorHeight,
    bool wantBorder = true,
    ValueChanged<String>? onChanged,
    FormFieldValidator<String>? validator,
    Color? fillColor,
    TextInputType? keyboardType,
    double? borderRadius,
    double? maxHeight,
    TextStyle? hintStyle,
    TextStyle? style,
    List<TextInputFormatter>? inputFormatters,
    TextCapitalization textCapitalization = TextCapitalization.none,
    bool autofocus = false,
    bool readOnly = false,
  }) {
    return SizedBox(
      height: maxHeight,
      child: Card(
        elevation: elevation ?? 2.px,
        shape: OutlineInputBorder(
            borderRadius:
            BorderRadius.circular(borderRadius ?? C.loginTextFieldRadius),
            borderSide: BorderSide.none),
        child: TextFormField(
          cursorHeight: cursorHeight,
          controller: controller,
          maxLines: maxLines,
          validator: validator,
          keyboardType: keyboardType ?? TextInputType.streetAddress,
          readOnly: readOnly,
          autofocus: autofocus,
          inputFormatters: inputFormatters,
          textCapitalization: textCapitalization,
          style: style ??
              Theme
                  .of(Get.context!)
                  .textTheme
                  .bodyMedium
                  ?.copyWith(
                  fontFamily: C.fontOpenSans, color: Col.onSecondary),
          decoration: InputDecoration(
            hintText: hintText,
            fillColor: fillColor ?? Col.inverseSecondary,
            hintStyle: hintStyle ??
                Theme
                    .of(Get.context!)
                    .textTheme
                    .bodyMedium
                    ?.copyWith(
                    fontFamily: C.fontOpenSans, color: Col.onSecondary),
            disabledBorder: OutlineInputBorder(
                borderSide: wantBorder
                    ? BorderSide(color: Col.inverseSecondary, width: 2.px)
                    : BorderSide.none,
                borderRadius: BorderRadius.circular(
                    borderRadius ?? C.loginTextFieldRadius)),
            contentPadding:
            contentPadding ?? EdgeInsets.symmetric(horizontal: 20.px),
            enabledBorder: OutlineInputBorder(
                borderSide: wantBorder
                    ? BorderSide(color: Col.inverseSecondary, width: 2.px)
                    : BorderSide.none,
                borderRadius: BorderRadius.circular(
                    borderRadius ?? C.loginTextFieldRadius)),
            border: OutlineInputBorder(
                borderSide: wantBorder
                    ? BorderSide(color: Col.primary, width: 2.px)
                    : BorderSide.none,
                borderRadius: BorderRadius.circular(
                    borderRadius ?? C.loginTextFieldRadius)),
            errorBorder: OutlineInputBorder(
                borderSide: wantBorder
                    ? BorderSide(color: Col.error, width: 2.px)
                    : BorderSide.none,
                borderRadius: BorderRadius.circular(
                    borderRadius ?? C.loginTextFieldRadius)),
          ),
        ),
      ),
    );
  }

  static Widget commonDivider(
      {double? height, double? width, double? borderRadius, Color? color}) {
    return Container(
      height: height ?? 1.px,
      width: width,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(borderRadius ?? 2.px),
          color: color ?? Col.secondary),
    );
  }

  static Widget commonAppBarWithoutActon({VoidCallback? onPressed,
    required String title,
    VoidCallback? clickOnClearButton,
    bool wantClearButton = false,
    bool wantBackButton = true}) {
    return Column(
      children: [
        Container(
          height: CM.getAppBarSize(),
          margin: EdgeInsets.only(top: CM.getToolBarSize()),
          padding: EdgeInsets.symmetric(horizontal: C.margin / 2),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              wantBackButton
                  ? IconButton(
                onPressed: onPressed,
                icon: Icon(Icons.arrow_back, color: Col.secondary),
                splashRadius: C.iconButtonRadius,
                padding: EdgeInsets.zero,
              )
                  : const SizedBox(),
              Expanded(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10.px),
                  child: Text(
                    title,
                    style: CT.alegreyaDisplaySmall(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
              wantClearButton
                  ? Padding(
                padding: EdgeInsets.symmetric(horizontal: C.margin / 2),
                child: commonTextButton(
                  onPressed: clickOnClearButton!,
                  child: Text(
                    C.textClearAll,
                    style: CT.openSansTitleLarge(),
                  ),
                ),
              )
                  : const SizedBox()
            ],
          ),
        ),
        Divider(
          color: Col.borderColor,
          thickness: 2.px,
          height: 0.px,
        ),
      ],
    );
  }

  static Widget commonAppBarWithActon({
    VoidCallback? clickOnBackButton,
    VoidCallback? clickOnLikeButton,
    VoidCallback? clickOnShareButton,
    VoidCallback? clickOnInfoButton,
    VoidCallback? clickOnZoomButton,
    VoidCallback? clickOnMenuButton,
    Widget? menuButton,
    bool wantLikeButton = true,
    bool wantTitle = false,
    String? title,
    bool wantShareButton = true,
    bool wantInfoButton = true,
    bool wantZoomButton = false,
    bool wantMenuButton = false,
    bool wantBackButton = true,
    bool wantSelectedLikeButton = false,
  }) {
    List<String> list = ["Easy", "Medium", "Hard"];
    return Column(
      children: [
        Container(
          height: CM.getAppBarSize(),
          margin: EdgeInsets.only(top: CM.getToolBarSize()),
          padding: EdgeInsets.symmetric(horizontal: C.margin / 2),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              wantBackButton
                  ? IconButton(
                onPressed: clickOnBackButton,
                icon: Icon(Icons.arrow_back, color: Col.secondary),
                splashRadius: C.iconButtonRadius,
                padding: EdgeInsets.zero,
              )
                  : const SizedBox(),
              wantTitle
                  ? Expanded(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10.px),
                  child: Text(
                    title!,
                    style: CT.alegreyaDisplaySmall(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              )
                  : const SizedBox(),
              Expanded(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10.px),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      if (wantZoomButton)
                        IconButton(
                          onPressed: clickOnZoomButton,
                          icon: Image.asset(
                            C.imageZoomLogo,
                            height: 25.px,
                            width: 25.px,
                          ),
                          splashRadius: C.iconButtonRadius,
                          padding: EdgeInsets.zero,
                        ),
                      if (wantLikeButton)
                        IconButton(
                          onPressed: clickOnLikeButton,
                          icon: wantSelectedLikeButton
                              ? Icon(
                            Icons.favorite,
                            color: Col.error,
                          )
                              : Icon(Icons.favorite_border,
                              color: Col.secondary),
                          splashRadius: C.iconButtonRadius,
                          padding: EdgeInsets.zero,
                        ),
                      if (wantShareButton)
                        IconButton(
                          onPressed: clickOnShareButton,
                          icon: Icon(Icons.share, color: Col.secondary),
                          splashRadius: C.iconButtonRadius,
                          padding: EdgeInsets.zero,
                        ),
                      if (wantMenuButton)
                        menuButton!,
                      if (wantInfoButton)
                        IconButton(
                          onPressed: clickOnInfoButton,
                          icon: Image.asset(
                            C.imageInfoLogo,
                            height: 30.px,
                            width: 30.px,
                          ),
                          splashRadius: C.iconButtonRadius,
                          padding: EdgeInsets.zero,
                        )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Divider(
          color: Col.borderColor,
          thickness: 2.px,
          height: 0.px,
        ),
      ],
    );
  }

  static Widget commonTextFieldForSearch({double? elevation,
    String? hintText,
    EdgeInsetsGeometry? contentPadding,
    TextEditingController? controller,
    int? maxLines = 1,
    ValueChanged<String>? onChanged,
    FormFieldValidator<String>? validator,
    Color? fillColor,
    TextInputType? keyboardType,
    double? borderRadius,
    List<TextInputFormatter>? inputFormatters,
    TextCapitalization textCapitalization = TextCapitalization.none,
    bool autofocus = false,
    ValueChanged<String>? onFieldSubmitted,
    bool readOnly = false,
    TextInputAction? textInputAction,
    required VoidCallback clickOnSearchIcon,
    required VoidCallback clickOnFilterIcon}) {
    return Card(
      elevation: elevation ?? 2.px,
      color: fillColor,
      shape: OutlineInputBorder(
          borderRadius:
          BorderRadius.circular(borderRadius ?? C.loginTextFieldRadius),
          borderSide: BorderSide.none),
      child: TextFormField(
        controller: controller,
        maxLines: maxLines,
        onFieldSubmitted: onFieldSubmitted,
        textInputAction: textInputAction,
        onChanged: onChanged,
        validator: validator,
        keyboardType: keyboardType,
        readOnly: readOnly,
        autofocus: autofocus,
        inputFormatters: inputFormatters,
        textCapitalization: textCapitalization,
        style: CT.alegreyaBodySmall(),
        decoration: InputDecoration(
          hintText: hintText,
          fillColor: fillColor ?? Col.inverseSecondary,
          prefixIcon: IconButton(
            onPressed: clickOnSearchIcon,
            icon: Image.asset(
              C.imageSearchPageLogo,
              height: 30.px,
              width: 30.px,
            ),
          ),
          suffixIcon: IconButton(
            onPressed: clickOnFilterIcon,
            icon: Image.asset(
              C.imageFilterLogo,
              height: 12.px,
              width: 20.px,
            ),
            splashRadius: C.iconButtonRadius,
          ),
          hintStyle: CT.alegreyaBodySmall(),
          contentPadding:
          contentPadding ?? EdgeInsets.symmetric(horizontal: 20.px),
          enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.circular(
                  borderRadius ?? C.loginTextFieldRadius)),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(
                  borderRadius ?? C.loginTextFieldRadius)),
          errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(
                  borderRadius ?? C.loginTextFieldRadius)),
        ),
      ),
    );
  }

  static Widget commonReadMoreText({
    required String value,
    int? maxLine,
  }) {
    final v = value.obs;
    return Obx(() {
      return ReadMoreText(
        v.value,
        style: CT.openSansTitleSmall(),
        moreStyle: Theme
            .of(Get.context!)
            .textTheme
            .titleLarge
            ?.copyWith(color: Col.darkBlue, fontFamily: C.fontOpenSans),
        lessStyle: Theme
            .of(Get.context!)
            .textTheme
            .titleLarge
            ?.copyWith(color: Col.darkBlue, fontFamily: C.fontOpenSans),
        trimLines: maxLine ?? 3,
        trimLength: 7,
        trimCollapsedText: C.textReadMore,
        callback: (val) {
          if (val) {} else {
            v.value = v.value.replaceAll("Read More", "");
          }
        },
        trimExpandedText: "  ${C.textReadLess}",
        trimMode: TrimMode.Line,
      );
    });
  }

  static Widget commonRattingView({required double rating,
    double? size,
    EdgeInsets itemPadding = EdgeInsets.zero}) =>
      RatingBarIndicator(
        rating: rating,
        itemBuilder: (context, index) =>
            Icon(
              Icons.star,
              color: Col.primary,
            ),
        itemPadding: itemPadding,
        itemCount: 5,
        itemSize: size ?? 16.px,
        direction: Axis.horizontal,
      );

  static Widget commonLinearProgressBar({required double value}) =>
      ClipRRect(
        borderRadius: BorderRadius.circular(20.px),
        child: LinearProgressIndicator(
          color: Col.primary,
          backgroundColor: Col.primaryColor,
          value: value,
          minHeight: 10.px,
        ),
      );

  static commonProgressBarView() =>
      CircularProgressIndicator(
        backgroundColor: const Color(0xff7C7C7C).withOpacity(.5),
        strokeWidth: 3,
      );
}
