import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:woo_english/app/api/api_constant/api_constant.dart';
import 'package:woo_english/app/api/api_model/get_dashboard_data_model.dart';
import 'package:woo_english/app/api/http_methods/http_methods.dart';
import 'package:woo_english/app/app_controller/app_controller.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/modules/book_detail/controllers/book_detail_controller.dart';
import 'package:woo_english/app/modules/book_detail/views/book_detail_view.dart';
import 'package:woo_english/app/modules/book_list/controllers/book_list_controller.dart';
import 'package:woo_english/app/modules/book_list/views/book_list_view.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class VideoBookController extends AppController {
  int intValue = 1;
  final count = 0.obs;
  final inAsyncCall = false.obs;
  String bookId = "";
  String categoryId = "";
  bool like = false;

  final isLiked = false.obs;
  String id = "";
  String videoId ="";
  late YoutubePlayerController videoController ;

  Map<String, dynamic> bodyParamsForBookLikeUnlike = {};

  final responseCode = 0.obs;
  final getVideoBook = Rxn<GetDashBoardBooksModel>();
  Map<String, dynamic> queryParametersForVideoBook = {};

  final responseCodeSimilarBook = 0.obs;
  final getSimilarBookModel = Rxn<GetDashBoardBooksModel>();
  List<Books> bookList = [];
  Map<String, dynamic> queryParametersForSimilarBooks = {};

  Map<String, dynamic> bodyParamsForAddViewBook = {};


  @override
  void onInit() {
    super.onInit();
    onReload();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  onReload() {
    connectivity.onConnectivityChanged.listen((event) async {
      if (await CM.internetConnectionCheckerMethod()) {
        onInit();
      } else {}
    });
  }

  Future<void> myOnInit() async {
    inAsyncCall.value = true;
    isLiked.value = like;
    await addViewBookApiCalling();
    await getVideoBooksApiCalling();
    inAsyncCall.value = false;
    videoId=YoutubePlayer.convertUrlToId(getVideoBook.value?.book?.video??"")!;
    videoController=YoutubePlayerController(
      initialVideoId: YoutubePlayer.convertUrlToId(videoId)!,
      flags: const YoutubePlayerFlags(
      ),
    );
    await getSimilarBooksApiCalling();
    videoController.play();
  }

  void increment() => count.value++;

  Future<void> getVideoBooksApiCalling() async {
    queryParametersForVideoBook = {
      ApiKey.bookId:bookId,
    };
    http.Response? response = await HttpMethod.instance.getRequestForParams(
        baseUriForParams: UriConstant.baseUriForParams,
        endPointUri: UriConstant.endPointGetVideoBook,
        queryParameters: queryParametersForVideoBook);
    responseCode.value = response?.statusCode ?? 0;
    queryParametersForVideoBook.clear();
    if (CM.responseCheckForGetMethod(response: response)) {
      getVideoBook.value = GetDashBoardBooksModel.fromJson(jsonDecode(response?.body ?? ""));
    }
  }

  Future<void> getSimilarBooksApiCalling() async {
    queryParametersForSimilarBooks = {
      ApiKey.categoryId: categoryId,
      ApiKey.inBookDetails: "1",
    };
    http.Response? response = await HttpMethod.instance.getRequestForParams(
        baseUriForParams: UriConstant.baseUriForParams,
        endPointUri: UriConstant.endPointGetSimilarBook,
        queryParameters: queryParametersForSimilarBooks);
    responseCodeSimilarBook.value = response?.statusCode ?? 0;
    queryParametersForSimilarBooks.clear();
    if (CM.responseCheckForGetMethod(response: response)) {
      getSimilarBookModel.value =
          GetDashBoardBooksModel.fromJson(jsonDecode(response?.body ?? ""));
      bookList = getSimilarBookModel.value?.books ?? [];
    }
  }

  Future<bool> bookLikeUnlikeApiCalling() async {
    bodyParamsForBookLikeUnlike = {
      ApiKey.bookId: bookId,
    };
    http.Response? response = await HttpMethod.instance.postRequest(
        url: UriConstant.endPointAddUserFavorite,
        bodyParams: bodyParamsForBookLikeUnlike);
    if (CM.responseCheckForPostMethod(response: response)) {
      bodyParamsForBookLikeUnlike.clear();
      return true;
    } else {
      bodyParamsForBookLikeUnlike.clear();
      return false;
    }
  }

  Future<bool> addViewBookApiCalling() async {
    bodyParamsForAddViewBook = {
      ApiKey.bookId: bookId,
      ApiKey.video:"yes",
    };

    http.Response? response = await HttpMethod.instance.postRequest(
        url: UriConstant.endPointAddViewBook,
        bodyParams: bodyParamsForAddViewBook);
    if (CM.responseCheckForPostMethod(response: response)) {
      bodyParamsForAddViewBook.clear();
      return true;
    } else {
      bodyParamsForAddViewBook.clear();
      return false;
    }
  }

  void clickOnBackButton() {
    inAsyncCall.value = true;
    Get.back( );
    inAsyncCall.value = false;
  }

  Future<void> clickOnLikeAppBarButton() async {
    inAsyncCall.value = true;
    if (await bookLikeUnlikeApiCalling()) {
      isLiked.value = !isLiked.value;
    }
    inAsyncCall.value = false;
  }

  void clickOnShareButton() {
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  Future<void> clickOnParticularBookForList({required int index}) async {
    inAsyncCall.value = true;
    videoController.pause();
    String tag = CM.getRandomNumber();
    Get.put(BookDetailController(), tag: tag);
    await Navigator.of(Get.context!).push(
      MaterialPageRoute(
        builder: (context) => BookDetailView(
          tag: tag,
          bookId: bookList[index].id.toString(),
          categoryId: bookList[index].category.toString(),
          isLiked: getSimilarBookModel.value?.favorite
              ?.contains(bookList[index].id.toString()),
        ),
      ),
    );
    await Get.delete<BookDetailController>(tag: tag);
    videoController.play();
    inAsyncCall.value = false;
  }

  void clickOnSoundButton({required int index}) {
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  void clickOnLikeButton({required int index}) {
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  Future<void> clickOnSeeMoreBooks({required String id}) async {
    inAsyncCall.value = true;
    videoController.pause();
    String tag = CM.getRandomNumber();
    Get.put(BookListController(), tag: tag);
    await Navigator.of(Get.context!).push(
      MaterialPageRoute(
        builder: (context) => BookListView(tag: tag, title: id,categoryId: categoryId),
      ),
    );
    await Get.delete<BookListController>(tag: tag);
    videoController.play();
    inAsyncCall.value = false;
  }
}
