import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:get/get.dart';
import 'package:woo_english/app/api/api_constant/api_constant.dart';
import 'package:woo_english/app/api/api_model/get_dashboard_data_model.dart';
import 'package:woo_english/app/api/http_methods/http_methods.dart';
import 'package:woo_english/app/app_controller/app_controller.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';

class NotificationsController extends AppController {
  final count = 0.obs;
  final inAsyncCall = false.obs;
  final loadMoreData=false.obs;
  final responseCode=0.obs;
  Map<String, dynamic> queryParametersForUserNotificationApi = {};
  final getDataModel = Rxn<GetDashBoardBooksModel>();
  List<Notification> notificationList = [];
  String limit = "10";
  int offset = 0;

  @override
  Future<void>  onInit() async {
    super.onInit();
    inAsyncCall.value=true;
    await getUserNotificationApiCalling();
    inAsyncCall.value=false;
    onReload();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  onReload(){
    connectivity.onConnectivityChanged.listen((event) async {
      if(await CM.internetConnectionCheckerMethod())
      {
        onInit();
      }
      else
      {

      }
    });
  }

  Future<void> onRefresh() async {
    offset=0;
    await  onInit();
  }

  Future<bool> onLoadMore() async{
    offset=offset+10;
    await getUserNotificationApiCalling();
    increment();
    return true;
  }


  Future<void> getUserNotificationApiCalling() async {
    queryParametersForUserNotificationApi = {
      ApiKey.limit: limit,
      ApiKey.offset: offset.toString(),
    };
    http.Response? response = await HttpMethod.instance.getRequestForParams(
        baseUriForParams: UriConstant.baseUriForParams,
        endPointUri: UriConstant.endPointGetNotification,
        queryParameters: queryParametersForUserNotificationApi);
    responseCode.value=response?.statusCode??0;
    queryParametersForUserNotificationApi.clear();
    if (CM.responseCheckForGetMethod(response: response)) {
      getDataModel.value =
          GetDashBoardBooksModel.fromJson(jsonDecode(response?.body ?? ""));
      if(getDataModel.value?.notification==null||getDataModel.value!.notification!.isEmpty )
        {
          loadMoreData.value=true;
        }
      else
        {
          loadMoreData.value=false;
        }

      if(offset==0)
        {
          notificationList.clear();
        }
      if (getDataModel.value != null &&
          getDataModel.value?.notification != null &&
          getDataModel.value!.notification!.isNotEmpty) {
        getDataModel.value?.notification?.forEach((element) {
          notificationList.add(element);
        });
      }
    }
  }



  void increment() => count.value++;

  void clickOnBackButton() {
    inAsyncCall.value = true;
    Get.back();
    inAsyncCall.value = false;
  }

  void clickOnClearButton() {
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  void clickOnParticularNotification({required int index}) {
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  void clickOnCrossIcon({required int index}) {
    inAsyncCall.value=true;
    inAsyncCall.value=false;
  }


}
