import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:woo_english/app/api/api_model/get_dashboard_data_model.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/common/common_text_styles/common_text_styles.dart';
import 'package:woo_english/app/modules/search_suggestion_list/controllers/search_suggestion_list_controller.dart';
import 'package:woo_english/app/theme/colors/colors.dart';
import 'package:woo_english/app/theme/constants/constants.dart';

class FilterBottomSheet extends GetView<SearchSuggestionListController> {
  const FilterBottomSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: C.margin),
      child: ScrollConfiguration(
        behavior: ListScrollBehaviour(),
        child: ListView(
          shrinkWrap: true,
          padding: EdgeInsets.only(bottom: 20.px),
          children: [
            Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 5.px),
                child: Text(
                  C.textFilter,
                  style: CT.alegreyaHeadLineLarge(),
                ),
              ),
            ),
            SizedBox(
              height: 10.px,
            ),
            commonFilterView(
                list: controller.categoryList,
                title: C.textCategories,
                selectedList: controller.selectedCategory, key: 0),
            commonFilterView(
                list: controller.englishAccentList,
                title: C.textEnglishAssent,
                selectedList: controller.selectedEnglishAssent, key: 1),
            commonFilterView(
                list: controller.levelList,
                title: C.textLevel,
                selectedList: controller.selectedLevel,
                wantDivider: false, key: 2),
          ],
        ),
      ),
    );
  }

  Widget commonFilterView(
          {required String title,
          required List<Filters> list,
          required List<int> selectedList,
            required int key,
          bool wantDivider = true}) =>
      Obx(() {
        controller.count.value;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            textViewTitle(value: title),
            SizedBox(
              height: 2.px,
            ),
            listViewFilters(list: list, selectedList: selectedList, key: key),
            SizedBox(
              height: 8.px,
            ),
            if (wantDivider)
              Divider(
                color: Col.primaryColor,
                height: 0.px,
                thickness: 3.px,
              )
          ],
        );
      });

  Widget textViewTitle({
    required String value,
  }) =>
      Text(
        value,
        style: CT.openSansBodyMedium(),
      );

  Widget listViewFilters(
          {required List<Filters> list, required List<int> selectedList,required int key}) =>
     Obx(() {
       controller.count.value;
       return Wrap(
         children: List.generate(
           list.length,
               (index) => list[index].name!.isNotEmpty
               ? InkWell(
             onTap: () => controller.clickOnParticularFilter(
                 index: index, key: key),
             child: Container(
               margin: EdgeInsets.only(right: 10.px, bottom: 2.px),
               padding: EdgeInsets.symmetric(horizontal: 5.px),
               decoration: BoxDecoration(
                   color: selectedList[index] == list[index].id
                       ? Col.primary
                       : Col.inverseSecondary,
                   borderRadius: BorderRadius.circular(8.px)),
               child: textViewBrowsTitle(
                   list: list, index: index, selectedList: selectedList),
             ),
           )
               : const SizedBox(),
         ),
       );
     });

  Widget textViewBrowsTitle(
          {required List<Filters> list, required int index,  required List<int> selectedList}) =>
      Text(
        list[index].name ?? "",
        style: Theme.of(Get.context!).textTheme.bodyMedium?.copyWith(
            fontFamily: C.fontAlegreya,
            color:  selectedList.contains(list[index].id)
                ? Col.inverseSecondaryVariant
                : Col.textGrayColor),
      );
}
