import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:woo_english/app/api/api_constant/api_constant.dart';
import 'package:woo_english/app/api/http_methods/http_methods.dart';
import 'package:woo_english/app/app_controller/app_controller.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/modules/search_suggestion_list/views/filter_bottom_sheet.dart';
import 'package:woo_english/app/theme/colors/colors.dart';

import '../../../api/api_model/get_dashboard_data_model.dart';

class SearchSuggestionListController extends AppController {
  final count = 0.obs;
  final inAsyncCall = false.obs;
  final searchController = TextEditingController();
  Timer? searchOnStoppedTyping;

  final responseCode = 0.obs;
  Map<String, dynamic> queryParametersForSearchBook = {};
  final getDataNewReleaseBook = Rxn<GetDashBoardBooksModel>();
  List<Books> bookList = [];

  final getDataForCategory = Rxn<GetDashBoardBooksModel>();
  List<Filters> categoryList = [];
  List<Filters> englishAccentList = [];
  List<Filters> levelList = [];

  List<int> selectedCategory = [];
  List<int> selectedEnglishAssent = [];
  List<int> selectedLevel = [];

  List<int> category = [];
  List<int> englishAssent = [];
  List<int> level = [];

  String categoryValue = "";
 String englishAssentValue = "";
 String levelValue = "";

  @override
  Future<void> onInit() async {
    super.onInit();
    inAsyncCall.value = true;
    await getCategoryApiCalling();
    await getEnglishAccentApiCalling();
    await getLevelApiCalling();
    inAsyncCall.value = false;

    onReload();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  onReload() {
    connectivity.onConnectivityChanged.listen((event) async {
      if (await CM.internetConnectionCheckerMethod()) {
        onInit();
      } else {}
    });
  }

  void increment() => count.value++;

  Future<void> getSearchBookDataApiCalling({bool wantFilter = false}) async {
    if (wantFilter) {
      queryParametersForSearchBook = {
        ApiKey.category: categoryValue,
        ApiKey.englishAccent: englishAssentValue,
        ApiKey.level: levelValue,
      };
    } else {
      queryParametersForSearchBook = {
        ApiKey.bookName: searchController.text.toString().trim(),
      };
    }

    http.Response? response = await HttpMethod.instance.getRequestForParams(
        baseUriForParams: UriConstant.baseUriForParams,
        endPointUri: UriConstant.endPointGetSearchList,
        queryParameters: queryParametersForSearchBook);
    responseCode.value = response?.statusCode ?? 0;
    queryParametersForSearchBook.clear();
    if (CM.responseCheckForGetMethod(response: response)) {
      getDataNewReleaseBook.value =
          GetDashBoardBooksModel.fromJson(jsonDecode(response?.body ?? ""));
      if (getDataNewReleaseBook.value?.books != null) {
        bookList = getDataNewReleaseBook.value?.books ?? [];
      }
    }
  }

  Future<void> getCategoryApiCalling() async {
    http.Response? response = await HttpMethod.instance
        .getRequest(url: UriConstant.endPointGetCategory);
    if (CM.responseCheckForGetMethod(response: response)) {
      getDataForCategory.value =
          GetDashBoardBooksModel.fromJson(jsonDecode(response?.body ?? ""));
      if (getDataForCategory.value?.category != null) {
        getDataForCategory.value?.category?.forEach((element) {
          categoryList.add(element);
          selectedCategory.add(-1);
        });
      }
    }
  }

  Future<void> getEnglishAccentApiCalling() async {
    http.Response? response = await HttpMethod.instance
        .getRequest(url: UriConstant.endPointGetEnglishAssent);
    if (CM.responseCheckForGetMethod(response: response)) {
      getDataForCategory.value =
          GetDashBoardBooksModel.fromJson(jsonDecode(response?.body ?? ""));
      if (getDataForCategory.value?.englishAccent != null) {
        getDataForCategory.value?.englishAccent?.forEach((element) {
          englishAccentList.add(element);
          selectedEnglishAssent.add(-1);
        });
      }
    }
  }

  Future<void> getLevelApiCalling() async {
    http.Response? response =
        await HttpMethod.instance.getRequest(url: UriConstant.endPointGetLevel);
    if (CM.responseCheckForGetMethod(response: response)) {
      getDataForCategory.value =
          GetDashBoardBooksModel.fromJson(jsonDecode(response?.body ?? ""));
      if (getDataForCategory.value?.level != null) {
        getDataForCategory.value?.level?.forEach((element) {
          levelList.add(element);
          selectedLevel.add(-1);
        });
      }
    }
  }

  void clickOnBackButton() {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    Get.back();
    inAsyncCall.value = false;
  }

  void clickOnSearchIcon() {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  Future<void> clickOnFilterButton() async {
    CM.unFocsKeyBoard();
    showModalBottomSheet(
        context: Get.context!,
        builder: (context) => const FilterBottomSheet(),
        isDismissible: true,
        enableDrag: true,
        shape: OutlineInputBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(25.px),
              topRight: Radius.circular(25.px)),
        ),
        isScrollControlled: true,
        backgroundColor: Col.cardBackgroundColor);
  }

  Future<void> clickOnParticularBook({required int index}) async {
    /*  CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    String tag = CM.getRandomNumber();
    Get.put(BookDetailController(), tag: tag);
    await Navigator.of(Get.context!).push(
      MaterialPageRoute(
        builder: (context) => BookDetailView(tag: tag),
      ),
    );
    await Get.delete<BookDetailController>(tag: tag);
    inAsyncCall.value = false;*/
  }

  onChange({required String value}) {
    const duration = Duration(
        milliseconds:
            800); // set the duration that you want call search() after that.
    if (searchOnStoppedTyping != null) {
      searchOnStoppedTyping?.cancel(); // clear timer
    }
    searchOnStoppedTyping = Timer(duration, () async {
      await getSearchBookDataApiCalling();
    });
  }

  void clickOnArrowButton({required int index}) {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  Future<void> clickOnParticularFilter({required int index, required int key}) async {
    increment();
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    if (key == 0) {
      if ((selectedCategory[index] == categoryList[index].id) &&
          category.contains(selectedCategory[index])) {
        category.remove(selectedCategory[index]);

        selectedCategory[index] = -1;
      } else {
        selectedCategory[index] = categoryList[index].id ?? -1;
        category.add(categoryList[index].id ?? -1);
      }
    } else if (key == 1) {
      if ((selectedEnglishAssent[index] == englishAccentList[index].id) &&
          englishAssent.contains(selectedEnglishAssent[index])) {
        englishAssent.remove(selectedEnglishAssent[index]);
        selectedEnglishAssent[index] = -1;
      } else {
        selectedEnglishAssent[index] = englishAccentList[index].id ?? -1;
        englishAssent.add(englishAccentList[index].id ?? -1);
      }
    } else if (key == 2) {
      if ((selectedLevel[index] == levelList[index].id) &&
          level.contains(selectedLevel[index])) {
        level.remove(selectedLevel[index]);
        selectedLevel[index] = -1;
      } else {
        selectedLevel[index] = levelList[index].id ?? -1;
        level.add(levelList[index].id ?? -1);
      }
    }

    categoryValue = category.toString().replaceAll("]", "");
    categoryValue = categoryValue.toString().replaceAll("[", "");

    englishAssentValue = englishAssent.toString().replaceAll("]", "");
    englishAssentValue = englishAssentValue.toString().replaceAll("[", "");

    levelValue = level.toString().replaceAll("]", "");
    levelValue = levelValue.toString().replaceAll("[", "");

    Get.back();
    responseCode.value=0;
    await getSearchBookDataApiCalling(wantFilter: true);

    inAsyncCall.value = false;
  }

  clickOnSearchKeyBordButton({required String value}) async {
    /* CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    String tag = CM.getRandomNumber();
    Get.put(BookDetailController(), tag: tag);
    await Navigator.of(Get.context!).push(
      MaterialPageRoute(
        builder: (context) => BookDetailView(tag: tag),
      ),
    );
    await Get.delete<BookDetailController>(tag: tag);
    inAsyncCall.value = false;*/
  }
}
