import 'package:get/get.dart';
import 'package:woo_english/app/api/api_constant/api_constant.dart';
import 'package:woo_english/app/api/http_methods/http_methods.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/data/local_database/database_const/database_const.dart';
import 'package:woo_english/app/data/local_database/database_helper/database_helper.dart';
import 'package:http/http.dart' as http;

class AppSettingController extends GetxController {
  final count = 0.obs;
  final inAsyncCall = false.obs;
  final notificationValue = false.obs;
  final modeValue = false.obs;
  final applicationUpdateValue = false.obs;
  Map<String, dynamic> queryParametersForNotificationOnOff = {};
  Map<String, dynamic> queryParametersForAppUpdateOnOff = {};

  @override
  Future<void> onInit() async {
    super.onInit();
    inAsyncCall.value = true;
    notificationValue.value = await DatabaseHelper.databaseHelperInstance
            .getParticularData(key: DatabaseConst.columnNotificationOnOff) ==
        "1";
    applicationUpdateValue.value = await DatabaseHelper.databaseHelperInstance
            .getParticularData(key: DatabaseConst.columnAppUpdateOnOff) ==
        "1";
    inAsyncCall.value = false;
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() => count.value++;

  Future<void> onRefresh() async {
    await  onInit();
  }

  Future<bool> notificationOnOffApiCalling() async {
    queryParametersForNotificationOnOff = {
      ApiKey.notification: notificationValue.value ? "0" : "1",
    };
    http.Response? response = await HttpMethod.instance.getRequestForParams(
        queryParameters: queryParametersForNotificationOnOff,
        baseUriForParams: UriConstant.baseUriForParams,
        endPointUri: UriConstant.endPointNotificationOnOff);
    if (CM.responseCheckForPostMethod(response: response)) {
      queryParametersForNotificationOnOff.clear();
      return true;
    } else {
      queryParametersForNotificationOnOff.clear();
      return false;
    }
  }

  Future<bool> appUpdateOnOffApiCalling() async {
    queryParametersForAppUpdateOnOff = {
      ApiKey.appUpdate: applicationUpdateValue.value ? "0" : "1",
    };
    http.Response? response = await HttpMethod.instance.getRequestForParams(
        baseUriForParams: UriConstant.baseUriForParams,
        endPointUri: UriConstant.endPointAppUpdateOnOff,
        queryParameters: queryParametersForAppUpdateOnOff);
    if (CM.responseCheckForPostMethod(response: response)) {
      queryParametersForAppUpdateOnOff.clear();
      return true;
    } else {
      queryParametersForAppUpdateOnOff.clear();
      return false;
    }
  }

  void clickOnBackButton() {
    inAsyncCall.value = true;
    Get.back();
    inAsyncCall.value = false;
  }

  Future<void> notificationOnChange({required bool value}) async {
    inAsyncCall.value = true;
    if (await notificationOnOffApiCalling()) {
      DatabaseHelper.databaseHelperInstance.updateParticularData(key: DatabaseConst.columnNotificationOnOff, val: notificationValue.value?"0":"1");

      notificationValue.value = value;
    }
    inAsyncCall.value = false;
  }

  void modeOnChange({required bool value}) {
    inAsyncCall.value = true;
    modeValue.value = value;
    inAsyncCall.value = false;
  }

  Future<void> applicationUpdateOnChange({required bool value}) async {
    inAsyncCall.value = true;
    if (await notificationOnOffApiCalling()) {
      DatabaseHelper.databaseHelperInstance.updateParticularData(key: DatabaseConst.columnAppUpdateOnOff, val: applicationUpdateValue.value?"0":"1");

      applicationUpdateValue.value = value;
    }
    inAsyncCall.value = false;
  }
}
