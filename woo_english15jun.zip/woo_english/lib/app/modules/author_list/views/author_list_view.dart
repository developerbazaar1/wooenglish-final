import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/common/common_text_styles/common_text_styles.dart';
import 'package:woo_english/app/common/common_widget/common_widget.dart';
import 'package:woo_english/app/theme/constants/constants.dart';
import 'package:woo_english/model_progress_bar/model_progress_bar.dart';

import '../controllers/author_list_controller.dart';

class AuthorListView extends GetView<AuthorListController> {
  const AuthorListView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Obx(() => ModalProgress(
          inAsyncCall: controller.inAsyncCall.value,
          child: Scaffold(
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            body: Column(
              children: [
                appBarView(),
                if (controller.authorList.isNotEmpty &&
                    controller.getDataModel.value != null)
                  ScrollConfiguration(
                    behavior: ListScrollBehaviour(),
                    child: Expanded(
                      child: CW.commonRefreshIndicator(
                        onRefresh: () => controller.onRefresh(),
                        child: CustomScrollView(
                          slivers: [gridView()],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ));
  }

  Widget appBarView() => CW.commonAppBarWithoutActon(
      title: C.textFamousAuthors,
      onPressed: () => controller.clickOnBackButton());

  Widget gridView() => SliverPadding(
        padding: EdgeInsets.only(
            top: 18.px,
            left: C.margin,
            right: C.margin,
            bottom: C.margin + C.margin),
        sliver: SliverGrid.builder(
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () => controller.clickOnParticularAuthor(index: index),
              child: SizedBox(
                height: 127.px,
                width: 100.px,
                child: Column(
                  children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(100.px),
                        child: imageViewAuthor(
                            value:
                                controller.authorList[index].authorImage ?? ""),
                      ),
                    SizedBox(
                      height: 5.px,
                    ),
                    if (controller.authorList[index].name != null)
                      textAuthorName(
                          value: controller.authorList[index].name ?? "")
                  ],
                ),
              ),
            );
          },
          itemCount: controller.authorList.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              childAspectRatio: 0.78,
              crossAxisSpacing: 15.px,
              mainAxisSpacing: 15.px),
        ),
      );

  Widget imageViewAuthor({required String value}) {
    if (value.isNotEmpty) {
      return Image.network(
        CM.getImageUrl(value: value),
        height: 100.px,
        width: 100.px,
        fit: BoxFit.cover,
      );
    } else {
      return Image.asset(
        C.imageUserProfile,
        height: 100.px,
        width: 100.px,
        fit: BoxFit.cover,
      );
    }
  }

  Widget textAuthorName({required String value}) => Text(
        value,
        style: CT.alegreyaBodySmall(),
      );
}
