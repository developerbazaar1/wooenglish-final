import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:woo_english/app/api/api_constant/api_constant.dart';
import 'package:woo_english/app/api/api_model/get_dashboard_data_model.dart';
import 'package:woo_english/app/api/http_methods/http_methods.dart';
import 'package:woo_english/app/app_controller/app_controller.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/modules/book_detail/controllers/book_detail_controller.dart';
import 'package:woo_english/app/modules/book_detail/views/book_detail_view.dart';
import 'package:http/http.dart' as http;
import 'package:woo_english/app/theme/constants/constants.dart';

class BookListController extends AppController {
  int intValue=1;
  final count = 0.obs;
  final inAsyncCall = false.obs;
  String title = "";
  String id = "";
  String categoryId = "";
  String endPoint = "";
  List<BooksFilter> listOfFilter = [];
  List<String> selectedFilter=[];
  String limit = "10";
  int offset = 0;
  final statusCode = 0.obs;
  Map<String, dynamic> queryParametersForSeeMore = {};
  final getBooksModel = Rxn<GetDashBoardBooksModel?>();
  List<Books> listOfBooks = [];

  @override
  void onInit() {
    super.onInit();
    onReload();
  }

  Future<void> myOnInit() async {
    inAsyncCall.value = true;
    if (title == C.textMostPopularBooks) {
      endPoint = UriConstant.endPointGetPopularBooks;
    } else if (title == C.textYourFavorite) {
      endPoint = UriConstant.endPointGetFavoriteBooks;
    } else if (title == C.textNewRelease) {
      endPoint = UriConstant.endPointGetNewReleaseBooks;
    } else if (title == C.textMemberOnlyBooks) {
      endPoint = UriConstant.endPointGetMemberBooks;
    } else if (title == C.textSimilarBooks) {
      endPoint = UriConstant.endPointGetSimilarBook;
    }
    await getBookListApiCalling(isUserFavoriteData: title == C.textYourFavorite);
    inAsyncCall.value = false;
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  onReload() {
    connectivity.onConnectivityChanged.listen((event) async {
      if (await CM.internetConnectionCheckerMethod()) {
        onInit();
      } else {}
    });
  }

  Future<void> onRefresh() async {
    offset=0;
    await myOnInit();
  }

  Future<void> getBookListApiCalling({bool isUserFavoriteData = false}) async {
    if (isUserFavoriteData) {
      queryParametersForSeeMore = {
        ApiKey.limit: limit,
        ApiKey.offset: offset.toString(),
        ApiKey.isDashboard: "0",
      };
    } else if (title == C.textSimilarBooks) {
      queryParametersForSeeMore = {
        ApiKey.limit: limit,
        ApiKey.offset: offset.toString(),
        ApiKey.categoryId: categoryId.isNotEmpty ? categoryId : "",
        ApiKey.inBookDetails: "1",
      };
    } else {
      queryParametersForSeeMore = {
        ApiKey.limit: limit,
        ApiKey.offset: offset.toString(),

      };
    }
    if(selectedFilter.isNotEmpty)
      {
        queryParametersForSeeMore[ApiKey.genre]=selectedFilter[0];
        queryParametersForSeeMore[ApiKey.level]=selectedFilter[1];
      }
    http.Response? response = await HttpMethod.instance.getRequestForParams(
        baseUriForParams: UriConstant.baseUriForParams,
        endPointUri: endPoint,
        queryParameters: queryParametersForSeeMore);
    statusCode.value = response?.statusCode ?? 0;
    queryParametersForSeeMore.clear();
    if (CM.responseCheckForGetMethod(response: response)) {
      getBooksModel.value =
          GetDashBoardBooksModel.fromJson(jsonDecode(response?.body ?? ""));
      if(offset==0)
        {
          listOfBooks.clear();
        }
      if (getBooksModel.value?.books != null &&
          getBooksModel.value!.books!.isNotEmpty) {
        getBooksModel.value?.books?.forEach((element) {
          listOfBooks.add(element);
        });
      }
      listOfFilter.clear();
      selectedFilter.clear();
      if (getBooksModel.value?.genre != null &&
          getBooksModel.value!.genre!.isNotEmpty) {
        listOfFilter.add(BooksFilter(
            title: "Genre", filterList: getBooksModel.value?.genre));
        selectedFilter.add("");
      }
      if (getBooksModel.value?.level != null &&
          getBooksModel.value!.level!.isNotEmpty) {
        listOfFilter.add(BooksFilter(
            title: "Level", filterList: getBooksModel.value?.level));
        selectedFilter.add("");
      }
    }
  }

  void increment() => count.value++;

  void clickOnBackButton() {
    inAsyncCall.value = true;
    Get.back();
    inAsyncCall.value = false;
  }

  Future<void> clickOnParticularBook({required int index}) async {
    inAsyncCall.value = true;
    String tag = CM.getRandomNumber();
    Get.put(BookDetailController(), tag: tag);
    intValue=0;
    await Navigator.of(Get.context!).push(
      MaterialPageRoute(
        builder: (context) => BookDetailView(
            tag: tag,
            bookId: title == C.textYourFavorite?listOfBooks[index].bookId.toString():listOfBooks[index].id.toString(),
            isLiked: title == C.textYourFavorite
                ? true
                : getBooksModel.value!.favorite!
                    .contains(listOfBooks[index].id.toString()),
            categoryId: title == C.textYourFavorite
                ? listOfBooks[index].bookdetails?.category
                : listOfBooks[index].category),
      ),
    );
    await Get.delete<BookDetailController>(tag: tag);
    offset=0;
    await myOnInit();
    inAsyncCall.value = false;
  }

  void clickOnSoundButton({required int index}) {
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  void clickOnLikeButton({required int index}) {
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }
}

class BooksFilter {
  String? title;
  List<Filters>? filterList;

  BooksFilter({this.title, this.filterList});
}
