import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/common/common_text_styles/common_text_styles.dart';
import 'package:woo_english/app/common/common_widget/common_widget.dart';
import 'package:woo_english/app/theme/colors/colors.dart';
import 'package:woo_english/app/theme/constants/constants.dart';

import '../controllers/on_boarding_controller.dart';

class OnBoardingView extends GetView<OnBoardingController> {
  const OnBoardingView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Obx(() {
        controller.selectedIndex.value;
        return Container(
          decoration: const BoxDecoration(
              color: Colors.green,
              image: DecorationImage(
                  image: AssetImage(C.imageSplashScreenBackground),
                  fit: BoxFit.cover)),
          child: Scaffold(
              backgroundColor: Colors.transparent,
              body: Stack(
                children: [
                  PageView.builder(
                    controller: controller.pageController,
                    itemBuilder: (context, index) => ScrollConfiguration(
                      behavior: ListScrollBehaviour(),
                      child: ListView(
                        children: [
                          SizedBox(
                            height: CM.getDeviceSize(),
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: C.margin),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  imageViewOnBoarding(index: index),
                                  SizedBox(
                                    height: 20.px,
                                  ),
                                  textViewOnBoardingTitle(index: index),
                                  SizedBox(
                                    height: 11.px,
                                  ),
                                  textViewOnBoardingDescription(),
                                  SizedBox(
                                    height: 35.px,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    itemCount: controller.imageList.length,
                    onPageChanged: (value) => {controller.selectedIndex.value = value},
                  ),
                  Align(alignment: Alignment.topRight, child:Column(
                    children: [
                      SizedBox(height: 30.px,),
                      buttonViewSkip(),
                    ],
                  ),),
                  Align(
                    child: Column(
                      children: [
                        const Expanded(child: SizedBox.shrink()) ,
                        Padding(
                          padding:  EdgeInsets.symmetric(horizontal: C.margin),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  circleDotView( circleIndex: 0),
                                  SizedBox(
                                    width: 4.px,
                                  ),
                                  circleDotView( circleIndex: 1),
                                  SizedBox(
                                    width: 4.px,
                                  ),
                                  circleDotView( circleIndex: 2),
                                ],
                              ),
                              buttonViewNext(),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30.px,
                        )
                      ],
                    ),
                  )
                ],
              )),
        );
      }),
    );
  }

  Widget imageViewOnBoarding({required int index}) => Image.asset(
        controller.imageList[index],
        height: 300.px,
        width: 300.px,
      );

  Widget textViewOnBoardingTitle({required int index}) =>
      Text(controller.titleTextList[index],style: CT.playfairHeadLineSmall(),);

  Widget textViewOnBoardingDescription() => Text(C.textOnBoardingDescription,

  style: Theme.of(Get.context!).textTheme.bodySmall?.copyWith(color: Col.darkBlue,fontFamily:C.fontOpenSans ),
  textAlign: TextAlign.center,);

  Widget circleDotView({ required int circleIndex}) => Container(
        height: 10.px,
        width: 10.px,
        decoration: BoxDecoration(
            color:
                circleIndex == controller.selectedIndex.value ? Col.textGrayColor : Colors.transparent,
            borderRadius: BorderRadius.circular(10.px),
            border: Border.all(
                color: circleIndex == controller.selectedIndex.value
                    ? Col.textGrayColor
                    : Col.textGrayColor)),
      );

  Widget buttonViewNext() => CW.commonElevatedButton(
      onPressed: () =>controller.clickOnNextButton(),
      child: textViewNext(),
      height: 45.px,
      contentPadding: EdgeInsets.symmetric(horizontal: 20.px,),
      buttonMargin: EdgeInsets.zero,
      buttonColor: Col.darkBlue);

  Widget textViewNext() =>Text(C.textNext,style: CT.openSansDisplayLarge(),);

  Widget buttonViewSkip() =>  CW.commonTextButton(child: textViewSkip(), onPressed: () =>controller.clickOnSkipButton());

  Widget textViewSkip()=>Text(C.textSkip,style: Theme.of(Get.context!).textTheme.displaySmall?.copyWith(
      fontFamily: C.fontLato,color: Col.darkBlue,fontSize: 20.px
  ),);
}
