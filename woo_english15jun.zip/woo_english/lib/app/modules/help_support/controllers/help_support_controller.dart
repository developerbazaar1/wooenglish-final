import 'package:http/http.dart' as http;
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:woo_english/app/api/api_constant/api_constant.dart';
import 'package:woo_english/app/api/http_methods/http_methods.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';

class HelpSupportController extends GetxController {
  final count = 0.obs;
  final inAsyncCall = false.obs;
  Map<String, dynamic> bodyParamsForHelpAndSupport = {};
  TextEditingController writeSomethingController = TextEditingController();

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() => count.value++;

  Future<bool> helpAndSupportApiCalling() async {
    bodyParamsForHelpAndSupport = {
      ApiKey.msg: writeSomethingController.text,
    };
    http.Response? response = await HttpMethod.instance.postRequest(
        url: UriConstant.endPointHelpAndSupport,
        bodyParams: bodyParamsForHelpAndSupport);
    if (CM.responseCheckForPostMethod(response: response)) {
      bodyParamsForHelpAndSupport.clear();
      return true;
    } else {
      bodyParamsForHelpAndSupport.clear();
      return false;
    }
  }

  void clickOnBackButton() {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    Get.back();
    inAsyncCall.value = false;
  }

  Future<void> clickOnSubmitButton() async {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    if (writeSomethingController.text.isNotEmpty) {
      await helpAndSupportApiCalling();
      writeSomethingController.text="";
    } else {
      CM.showToast("Please write something!");
    }
    inAsyncCall.value = false;
  }
}
