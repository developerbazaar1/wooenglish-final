import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:woo_english/app/app_controller/app_controller.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/routes/app_pages.dart';
import 'package:woo_english/app/theme/constants/constants.dart';

import '../../../data/local_database/database_const/database_const.dart';
import '../../../data/local_database/database_helper/database_helper.dart';

class OnBoardingController extends AppController {
  final count = 0.obs;
  PageController pageController = PageController();
  final selectedIndex = 0.obs;
  List<String> imageList = [
    C.imageOnBoardingOne,
    C.imageOnBoardingTwo,
    C.imageOnBoardingThree
  ];
  List<String> titleTextList = [
    C.textOnBoardingOneTitle,
    C.textOnBoardingTwoTitle,
    C.textOnBoardingThreeTitle
  ];
  String token = "";

  @override
  Future<void> onInit() async {
    super.onInit();
    token = await DatabaseHelper.databaseHelperInstance
            .getParticularData(key: DatabaseConst.columnToken);
    onReload();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  onReload() {
    connectivity.onConnectivityChanged.listen((event) async {
      if (await CM.internetConnectionCheckerMethod()) {
        onInit();
      } else {}
    });
  }

  void increment() => count.value++;

  Future<void> clickOnNextButton() async {
    {
      if (selectedIndex.value != 2) {
        pageController.jumpToPage(selectedIndex.value + 1);
      } else {
        if (token.isNotEmpty) {
          await Get.offAllNamed(Routes.NAVIGATOR);
        } else {
          await Get.offAllNamed(Routes.SIGN_IN);
        }
      }
    }
  }

  Future<void> clickOnSkipButton() async {
    if (token.isNotEmpty) {
      await Get.offAllNamed(Routes.NAVIGATOR);
    } else {
      await Get.offAllNamed(Routes.SIGN_IN);
    }
  }
}
