import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:volume_controller/volume_controller.dart';
import 'package:woo_english/app/api/api_constant/api_constant.dart';
import 'package:woo_english/app/api/api_model/get_dashboard_data_model.dart';
import 'package:woo_english/app/api/http_methods/http_methods.dart';
import 'package:woo_english/app/app_controller/app_controller.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';

class ReadBookController extends AppController {
  int intValue = 1;
  final count = 0.obs;
  final inAsyncCall = false.obs;
  String id = "";
  String bookId = "";
  bool like = false;
  final haveAudio = false.obs;
  String audioUrl = "";
  List<TextEditingController> controllerList = [];
  final isLiked = false.obs;
  final isZoom = false.obs;
  final isCommentHidden = false.obs;
  final isShowMusicPlayer = true.obs;
  final selectedChapter = "".obs;
  final selectedChapterId = 0.obs;
  final selectedChapterContent = "".obs;
  final selectedChapterObject = Rxn<Chapters?>();
  final isPlaying = false.obs;
  final audioPlayed = false.obs;
  final currentPos = 0.obs;
  final currentPositionLabel = "00:00".obs;
  final setPlaybackRate = 1.0.obs;
  int maxDuration = 100;
  late Uint8List audioBytes;
  AudioPlayer player = AudioPlayer();
  int forwordBackWordValue = 10;
  final selectedMenu = 1.0.obs;
  final isMute = false.obs;
  final volumeListenerValue = 0.0.obs;
  final getVolume = 0.0.obs;

  Map<String, dynamic> bodyParamsForBookLikeUnlike = {};

  final responseCode = 0.obs;
  Map<String, dynamic> queryParametersForGetChapters = {};
  final getDataModel = Rxn<GetDashBoardBooksModel>();
  List<Chapters> chapterList = [];
  String limit = "10";
  int offset = 0;

  Map<String, dynamic> bodyParamsForAddViewBook = {};

  final responseCodeQuiz = 0.obs;
  Map<String, dynamic> queryParametersForQuiz = {};
  final getDataModelForQuiz = Rxn<GetDashBoardBooksModel>();
  List<Books> quizList = [];
  String quizLimit = "10";
  int quizOffset = 0;

  Map<String, dynamic> bodyParamsForSubmitQuestionAnswerApi = {};

  Map<String, dynamic> bodyParamsForAddFinishedBookApi = {};


  @override
  Future<void> onInit() async {
    super.onInit();
    onReload();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    if (isPlaying.value && audioPlayed.value) {
      player.stop();
    }
    super.onClose();
  }

  @override
  void dispose() {
    super.dispose();
  }

  onReload() {
    connectivity.onConnectivityChanged.listen((event) async {
      if (await CM.internetConnectionCheckerMethod()) {
        onInit();
      } else {}
    });
  }

  Future<void> myOnInit() async {
    inAsyncCall.value = true;
    isLiked.value = like;
    await getChaptersApiCalling();
    inAsyncCall.value = false;
    player.onDurationChanged.listen((Duration d) {
      maxDuration = d.inMilliseconds;
    });
    player.onPositionChanged.listen((Duration p) {
      currentPos.value = p.inMilliseconds;
      int sHours = Duration(milliseconds: currentPos.value).inHours;
      int sMinutes = Duration(milliseconds: currentPos.value).inMinutes;
      int sSeconds = Duration(milliseconds: currentPos.value).inSeconds;
      int rHours = sHours;
      int rMinutes = sMinutes - (sHours * 60);
      int rSeconds = sSeconds - (sMinutes * 60 + sHours * 60 * 60);
      currentPositionLabel.value =
      "${(rHours <= 9) ? '0$rHours' : '$rHours'}:${(rMinutes <= 9)
          ? '0$rMinutes'
          : '$rMinutes'}:${(rSeconds <= 9) ? '0$rSeconds' : '$rSeconds'}";
    });
    VolumeController().listener((volume) async {
      volumeListenerValue.value = volume;
      getVolume.value = await VolumeController().getVolume();
    });
  }

  Future<void> getChaptersApiCalling() async {
    queryParametersForGetChapters = {
      ApiKey.bookId: bookId,
    };
    http.Response? response = await HttpMethod.instance.getRequestForParams(
        baseUriForParams: UriConstant.baseUriForParams,
        endPointUri: UriConstant.endPointGetReadListen,
        queryParameters: queryParametersForGetChapters);
    queryParametersForGetChapters.clear();
    responseCode.value = response?.statusCode ?? 0;
    if (CM.responseCheckForGetMethod(response: response)) {
      getDataModel.value =
          GetDashBoardBooksModel.fromJson(jsonDecode(response?.body ?? ""));
      if (getDataModel.value != null &&
          getDataModel.value?.chapters != null &&
          getDataModel.value!.chapters!.isNotEmpty) {
        getDataModel.value?.chapters?.forEach((element) {
          chapterList.add(element);
        });
        if (getDataModel.value?.isQuiz != null &&
            getDataModel.value?.isQuiz != 0) {
          chapterList.add(Chapters(
            bookId: bookId,
            chapterName: "Quiz",
            id: -1,
          ));
        }
      }
    }
  }

  Future<bool> bookLikeUnlikeApiCalling() async {
    bodyParamsForBookLikeUnlike = {
      ApiKey.bookId: bookId,
    };
    http.Response? response = await HttpMethod.instance.postRequest(
        url: UriConstant.endPointAddUserFavorite,
        bodyParams: bodyParamsForBookLikeUnlike);
    if (CM.responseCheckForPostMethod(response: response)) {
      bodyParamsForBookLikeUnlike.clear();
      return true;
    } else {
      bodyParamsForBookLikeUnlike.clear();
      return false;
    }
  }

  Future<bool> addViewBookApiCalling({required String chapter}) async {
    bodyParamsForAddViewBook = {
      ApiKey.bookId: bookId,
      ApiKey.chapter: chapter
    };
    http.Response? response = await HttpMethod.instance.postRequest(
        url: UriConstant.endPointAddViewBook,
        bodyParams: bodyParamsForAddViewBook);
    if (CM.responseCheckForPostMethod(response: response)) {
      bodyParamsForAddViewBook.clear();
      return true;
    } else {
      bodyParamsForAddViewBook.clear();
      return false;
    }
  }

  Future<void> getQuizForBook() async {
    queryParametersForQuiz = {
      ApiKey.bookId: bookId,
    };
    http.Response? response = await HttpMethod.instance.getRequestForParams(
        baseUriForParams: UriConstant.baseUriForParams,
        endPointUri: UriConstant.endPointGetQuiz,
        queryParameters: queryParametersForQuiz);
    queryParametersForQuiz.clear();
    responseCodeQuiz.value = response?.statusCode ?? 0;
    if (CM.responseCheckForGetMethod(response: response)) {
      getDataModelForQuiz.value =
          GetDashBoardBooksModel.fromJson(jsonDecode(response?.body ?? ""));
      if (getDataModelForQuiz.value != null &&
          getDataModelForQuiz.value?.quiz != null &&
          getDataModelForQuiz.value!.quiz!.isNotEmpty) {
        getDataModelForQuiz.value?.quiz?.forEach((element) {
          quizList.add(element);
          TextEditingController controller = TextEditingController();
          controllerList.add(controller);
        });
      }
    }
  }

  Future<bool> submitQuestionAnswerApiCalling() async {
    List<String> questionArray = [];
    for (var element in quizList) {
      questionArray.add(element.question ?? "");
    }
    List<String> answerArray = [];
    for (var element in controllerList) {
      answerArray.add(element.text.trim().toString());
    }

    String question = questionArray.toString().replaceAll("[", "");
    question = question.toString().replaceAll("]", "");
    String answer = answerArray.toString().replaceAll("[", "");
    answer = answer.toString().replaceAll("]", "");

    bodyParamsForSubmitQuestionAnswerApi = {
      ApiKey.bookId: bookId,
      ApiKey.question: jsonEncode(question),
      ApiKey.answer: jsonEncode(answer),
    };
    http.Response? response = await HttpMethod.instance.postRequest(
        url: UriConstant.endPointSubmitQuizAnswer,
        bodyParams: bodyParamsForSubmitQuestionAnswerApi);
    if (CM.responseCheckForPostMethod(response: response)) {
      bodyParamsForSubmitQuestionAnswerApi.clear();
      return true;
    } else {
      bodyParamsForSubmitQuestionAnswerApi.clear();
      return false;
    }
  }

  Future<bool> finishBookApiCalling() async {
    bodyParamsForAddFinishedBookApi = {
      ApiKey.bookId: bookId,
    };
    http.Response? response = await HttpMethod.instance.postRequest(
        url: UriConstant.endPointAddFinishedBook,
        bodyParams: bodyParamsForAddFinishedBookApi);
    if (CM.responseCheckForPostMethod(response: response)) {
      bodyParamsForAddFinishedBookApi.clear();
      return true;
    } else {
      bodyParamsForAddFinishedBookApi.clear();
      return false;
    }
  }

  void increment() => count.value++;

  clickOnBackButton() {
    inAsyncCall.value = true;
    Get.back();
    inAsyncCall.value = false;
  }

  void clickOnInfoButton() {
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  Future<void> clickOnLikeAppBarButton() async {
    inAsyncCall.value = true;
    if (await bookLikeUnlikeApiCalling()) {
      isLiked.value = !isLiked.value;
    }
    inAsyncCall.value = false;
  }

  void clickOnShareButton() {
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  void clickOnMenuButton() {
    inAsyncCall.value = true;

    inAsyncCall.value = false;
  }

  void clickOnZoomButton() {
    inAsyncCall.value = true;
    isZoom.value = !isZoom.value;
    inAsyncCall.value = false;
  }

  onChangeChapter(Chapters? value) {
    inAsyncCall.value = true;

    inAsyncCall.value = false;
  }

  Future<void> clickOnSubmitButton() async {
    inAsyncCall.value = true;
    if (await submitQuestionAnswerApiCalling()) {
      if (await finishBookApiCalling()) {

      }
    }
    inAsyncCall.value = false;
  }

  void clickOnCommentHideShowButton() {
    inAsyncCall.value = true;
    isCommentHidden.value = !isCommentHidden.value;
    inAsyncCall.value = false;
  }

  void clickOnEyeHideButton() {
    inAsyncCall.value = true;
    isShowMusicPlayer.value = !isShowMusicPlayer.value;
    inAsyncCall.value = false;
  }

  void clickOnPlayBackButton() async {
    inAsyncCall.value = true;
    await player.seek(Duration(
        milliseconds: currentPos.value > 10000
            ? currentPos.value - 10000
            : currentPos.value));
    inAsyncCall.value = false;
  }

  void clickOnPauseAndPlayButton() async {
    inAsyncCall.value = true;
    if ((!isPlaying.value) && (!audioPlayed.value)) {
      await player.setSourceUrl(CM.getImageUrl(value: audioUrl));
      await player.play(UrlSource(CM.getImageUrl(value: audioUrl)));
      isPlaying.value = true;
      audioPlayed.value = true;
    } else if (audioPlayed.value && !isPlaying.value) {
      await player.resume();
      isPlaying.value = true;
      audioPlayed.value = true;
      await player.setPlaybackRate(setPlaybackRate.value);
    } else {
      await player.pause();
      isPlaying.value = false;
    }
    inAsyncCall.value = false;
  }

  Future<void> clickOnPlayForwordButton() async {
    inAsyncCall.value = true;
    await player.seek(Duration(
        milliseconds: currentPos.value != maxDuration
            ? currentPos.value + 10000
            : currentPos.value));
    inAsyncCall.value = false;
  }

  void clickOnMusicSoundButton({required double value}) {
    inAsyncCall.value = true;
    VolumeController().setVolume(value);
    inAsyncCall.value = false;
  }

  Future<void> changePlaybackRate(double value) async {
    inAsyncCall.value = true;
    setPlaybackRate.value = value;
    await player.setPlaybackRate(setPlaybackRate.value);
    inAsyncCall.value = false;
  }

  Future<void> onChangedSlider(double value) async {
    inAsyncCall.value = true;
    int seekVal = value.round();
    await player.seek(Duration(milliseconds: seekVal));
    currentPos.value = seekVal;
    inAsyncCall.value = false;
  }
}
