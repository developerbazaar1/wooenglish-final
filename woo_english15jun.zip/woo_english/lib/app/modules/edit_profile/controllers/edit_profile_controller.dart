import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:woo_english/app/api/api_constant/api_constant.dart';
import 'package:woo_english/app/api/api_model/user_data_model.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/data/local_database/database_const/database_const.dart';
import 'package:woo_english/app/data/local_database/database_helper/database_helper.dart';
import 'package:woo_english/app/modules/edit_profile/views/image_picker_bottom_sheet.dart';
import 'package:woo_english/custom_image_picker/custom_image_picker.dart';

import '../../../api/http_methods/http_methods.dart';

class EditProfileController extends GetxController {
  final count = 0.obs;
  final inAsyncCall = false.obs;
  final formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final mobileController = TextEditingController();
  final emailController = TextEditingController();
  final image = Rxn<File?>();
  String? userProfile ;
  String? userProfileCopy ;
  String? userName = "";
  String? userMobileNumber = "";
  String? userEmailAddress = "";
  Map<String, dynamic> bodyParamsForEditProfile = {};
  UserData? getUserDataModel;

  @override
  Future<void> onInit() async {
    super.onInit();
    inAsyncCall.value = true;
    userProfile = await DatabaseHelper.databaseHelperInstance
        .getParticularData(key: DatabaseConst.columnUserImage);
    userProfileCopy = await DatabaseHelper.databaseHelperInstance
        .getParticularData(key: DatabaseConst.columnUserImage);
    userName = await DatabaseHelper.databaseHelperInstance
        .getParticularData(key: DatabaseConst.columnName);
    userMobileNumber = await DatabaseHelper.databaseHelperInstance
        .getParticularData(key: DatabaseConst.columnMobile);
    userEmailAddress = await DatabaseHelper.databaseHelperInstance
        .getParticularData(key: DatabaseConst.columnEmail);
    nameController.text = userName ?? "";
    mobileController.text = userMobileNumber ?? "";
    emailController.text = userEmailAddress ?? "";
    inAsyncCall.value = false;
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  @override
  void dispose() {
    super.dispose();
  }

  void increment() => count.value++;

  Future<bool> updateProfileApiCalling() async {
    bodyParamsForEditProfile = {
      ApiKey.name: nameController.text,
      ApiKey.documentOld: userProfile,
    };
    http.Response? response = await HttpMethod.instance.updateMultipartRequest(
        url: UriConstant.endPointUpdateUserProfile,
        bodyParams: bodyParamsForEditProfile,
        multipartRequestType: 'POST',
        image: image.value,
        token: '${ApiKey.bearer} 48|xOQRRStJQCuIwshB9dBFf1DcQjUcMtlGoM8gXH6m',
        imageKey: ApiKey.document);
    if (CM.responseCheckForPostMethod(response: response)) {
      bodyParamsForEditProfile.clear();
      return true;
    } else {
      bodyParamsForEditProfile.clear();
      return false;
    }
  }

  Future<bool> getUserDataApiCalling() async {
    http.Response? response = await HttpMethod.instance.getRequest(
      url: UriConstant.endPointGetUserData,
    );
    if (CM.responseCheckForGetMethod(response: response)) {
      getUserDataModel = UserData.fromJson(jsonDecode(response?.body ?? ""));
      await CM.insertDataIntoDataBase(userData: getUserDataModel);
      return true;
    } else {
      return false;
    }
  }

  void clickOnBackButton() {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    Get.back();
    inAsyncCall.value = false;
  }

  void clickOnEditImage() {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    showModalBottomSheet(
        context: Get.context!,
        builder: (context) => const ImagePickerBottomSheet(),
        isDismissible: true,
        enableDrag: true,
        shape: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(25.px),
              topRight: Radius.circular(25.px)),
        ),
        isScrollControlled: true,
        backgroundColor: Colors.transparent);
    inAsyncCall.value = false;
  }

  Future<void> clickOnUpdateProfile() async {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    if (formKey.currentState!.validate()) {
      if (await updateProfileApiCalling()) {
        await getUserDataApiCalling();
        Get.back();
      }
    }
    inAsyncCall.value = false;
  }

  Future<void> clickOnTakePhoto() async {
    Get.back();
    image.value = await IP.pickImage(wantCropper: true);
  }

  Future<void> clickOnChooseFromLibrary() async {
    Get.back();
    image.value =
        await IP.pickImage(wantCropper: true, pickImageFromGallery: true);
  }

  void clickOnRemovePhoto() {
    inAsyncCall.value=true;
    Get.back();
    image.value = null;
    userProfile="";
    inAsyncCall.value=false;
  }

  void clickOnCancel() {
    Get.back();
  }
}
