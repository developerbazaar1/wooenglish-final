import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:woo_english/app/api/api_constant/api_constant.dart';
import 'package:woo_english/app/api/http_methods/http_methods.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/routes/app_pages.dart';
import 'package:http/http.dart' as http;

class SignUpController extends GetxController {
  final count = 0.obs;
  final absorbing = false.obs;
  final formKey = GlobalKey<FormState>();
  final isSignUpButtonClicked = false.obs;
  final nameController = TextEditingController();
  final mobileNumberController = TextEditingController();
  final emailAddressController = TextEditingController();
  Map<String, dynamic> bodyParamsForRegistration = {};
  Map<String, dynamic> responseMapForRegistration = {};
  String otp = "";
  String userId = "";

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() => count.value++;

  Future<bool> registrationApiCalling() async {
    bodyParamsForRegistration = {
      ApiKey.name: nameController.text,
      ApiKey.mobile: mobileNumberController.text,
      ApiKey.email: emailAddressController.text,
      ApiKey.deviceType:CM.getDeviceType(),
    };
    http.Response? response = await HttpMethod.instance.postRequest(
        url: UriConstant.endPointRegistration,
        bodyParams: bodyParamsForRegistration);
    if (CM.responseCheckForPostMethod(response: response)) {
      responseMapForRegistration = jsonDecode(response!.body);
      userId = responseMapForRegistration[ApiKey.user_id];
      otp = responseMapForRegistration[ApiKey.otp].toString();
      bodyParamsForRegistration.clear();
      return true;
    }
    else
    {
      bodyParamsForRegistration.clear();
      return false;
    }
  }

  Future<void> clickOnSignUpButton() async {
    CM.unFocsKeyBoard();
    absorbing.value = true;
    isSignUpButtonClicked.value = true;
    if (formKey.currentState!.validate()) {
      if(await registrationApiCalling())
        {
          Get.toNamed(Routes.VERIFICATION,arguments: [userId,otp,mobileNumberController.text]);
        }
    }
    isSignUpButtonClicked.value = false;
    absorbing.value = false;
  }

  void clickOnSignInButton() {
    CM.unFocsKeyBoard();
    absorbing.value = true;
    Get.back();
    absorbing.value = false;
  }
}
