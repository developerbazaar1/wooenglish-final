import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:woo_english/app/api/api_constant/api_constant.dart';
import 'package:woo_english/app/api/http_methods/http_methods.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/routes/app_pages.dart';
import 'package:http/http.dart' as http;

class SignInController extends GetxController {
  final count = 0.obs;
  final absorbing = false.obs;
  final formKey = GlobalKey<FormState>();
  final mobileNumberController = TextEditingController();
  final isOtpButtonClicked = false.obs;
  Map<String, dynamic> bodyParamsForLogin = {};
  Map<String, dynamic> responseMapForLogin = {};
  String otp = "";
  String userId = "";

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() => count.value++;

  Future<bool> loginApiCalling() async {
    bodyParamsForLogin = {
      ApiKey.mobile: mobileNumberController.text,
    };
    http.Response? response = await HttpMethod.instance.postRequest(
        url: UriConstant.endPointLogin, bodyParams: bodyParamsForLogin);
    if (CM.responseCheckForPostMethod(response: response)) {
      responseMapForLogin = jsonDecode(response!.body);
      userId = responseMapForLogin[ApiKey.user_id];
      otp = responseMapForLogin[ApiKey.otp].toString();
      bodyParamsForLogin.clear();
      return true;
    } else {
      bodyParamsForLogin.clear();
      return false;
    }
  }

  Future<void> clickOnGetOtpButton() async {
    CM.unFocsKeyBoard();
    absorbing.value = true;
    isOtpButtonClicked.value = true;
    if (formKey.currentState!.validate()) {
      if (await loginApiCalling()) {
        Get.toNamed(Routes.VERIFICATION,
            arguments: [userId, otp, mobileNumberController.text]);
      }
    }
    isOtpButtonClicked.value = false;
    absorbing.value = false;
  }

  void clickOnFacebookButton() {
    CM.unFocsKeyBoard();
    absorbing.value = true;
    absorbing.value = false;
  }

  void clickOnGoogleButton() {
    CM.unFocsKeyBoard();
    absorbing.value = true;
    absorbing.value = false;
  }

  void clickOnSignUpButton() {
    CM.unFocsKeyBoard();
    absorbing.value = true;
    Get.toNamed(Routes.SIGN_UP);
    absorbing.value = false;
  }
}
