
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class RefreshLoadMore extends StatefulWidget {

  /// Callback function on pull up to load more data | 上拉以加载更多数据的回调函数
  final Future<void> Function() onLoadMore;

  /// Whether it is the last page, if it is true, you can not load more | 是否为最后一页，如果为true，则无法加载更多
  final bool isLastPage;

  /// Child widget | 子组件
  final Widget child;

  /// Prompt text widget when there is no more data at the bottom | 底部没有更多数据时的提示文字组件
  final Widget? noMoreWidget;


  const RefreshLoadMore({
    Key? key,
    required this.child,
    required this.isLastPage,
    required this.onLoadMore,
    this.noMoreWidget,
  }) : super(key: key);

  @override
  RefreshLoadMoreState createState() => RefreshLoadMoreState();
}

class RefreshLoadMoreState extends State<RefreshLoadMore> {
  ScrollController scrollController = ScrollController();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    scrollController.addListener(() async {
      if (scrollController.position.pixels >=
          scrollController.position.maxScrollExtent) {
        if (_isLoading) {
          return;
        }

        if (mounted) {
          setState(() {
            _isLoading = true;
          });
        }

        if (!widget.isLastPage) {
          await widget.onLoadMore();
        }

        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    });
  }

  @override
  void dispose() {
    scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Widget mainWidget = ListView(
      controller: scrollController,
      physics: const AlwaysScrollableScrollPhysics(),
      padding: EdgeInsets.zero,
      children: [
        widget.child,
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 16.px,right: 16.px,bottom: 40.px,top: 16.px),
              child: _isLoading
                  ? const CupertinoActivityIndicator()
                  : widget.isLastPage
                  ? widget.noMoreWidget ??
                  Text(
                    'No more data',
                    style: TextStyle(
                      fontSize: 18,
                      color: Theme
                          .of(context)
                          .disabledColor,
                    ),
                  )
                  : Container(),
            )
          ],
        )
      ],
    );

    return mainWidget;
  }
}