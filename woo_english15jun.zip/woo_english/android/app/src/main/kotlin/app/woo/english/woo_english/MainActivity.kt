package app.woo.english.woo_english

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
