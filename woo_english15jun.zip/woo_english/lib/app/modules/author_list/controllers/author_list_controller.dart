import 'dart:convert';

import 'package:get/get.dart';
import 'package:woo_english/app/api/api_constant/api_constant.dart';
import 'package:woo_english/app/api/api_model/get_dashboard_data_model.dart';
import 'package:woo_english/app/api/http_methods/http_methods.dart';
import 'package:woo_english/app/app_controller/app_controller.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/routes/app_pages.dart';
import 'package:http/http.dart' as http;
class AuthorListController extends AppController {
  final count = 0.obs;
  final inAsyncCall = false.obs;
  Map<String,dynamic> queryParametersForAuthors={};
  final getDataModel = Rxn<GetDashBoardBooksModel>();
  List<Authors> authorList=[];
  String limit="10";
  int offset=0;

  @override
  Future<void> onInit() async {
    super.onInit();
    inAsyncCall.value=true;
    await getAuthorsApiCalling();
    inAsyncCall.value=false;
    onReload();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  onReload() {
    connectivity.onConnectivityChanged.listen((event) async {
      if (await CM.internetConnectionCheckerMethod()) {
        onInit();
      } else {}
    });
  }

  Future<void> onRefresh() async {
    offset=0;
    await onInit();
  }

  Future<void> getAuthorsApiCalling() async {
    queryParametersForAuthors = {
      ApiKey.limit:limit,
      ApiKey.offset:offset.toString(),
    };
    http.Response? response = await HttpMethod.instance.getRequestForParams(
        baseUriForParams: UriConstant.baseUriForParams,
        endPointUri: UriConstant.endPointGetAuthors,
        queryParameters: queryParametersForAuthors);
    queryParametersForAuthors.clear();
    if (CM.responseCheckForGetMethod(response: response)) {
      getDataModel.value = GetDashBoardBooksModel.fromJson(jsonDecode(response?.body ?? ""));
      if(offset==0)
        {
          authorList.clear();
        }
      if(getDataModel.value !=null && getDataModel.value?.authors != null && getDataModel.value!.authors!.isNotEmpty)
        {
          getDataModel.value?.authors?.forEach((element) {
            authorList.add(element);
          });
        }
    }
  }

  void increment() => count.value++;

  void clickOnBackButton() {
    inAsyncCall.value = true;
    Get.back();
    inAsyncCall.value = false;
  }

  Future<void> clickOnParticularAuthor({required int index}) async {
    inAsyncCall.value = true;
    await Get.toNamed(Routes.AUTHOR,arguments:[authorList[index].name??"",authorList[index].id.toString()??""]);
    offset=0;
    await getAuthorsApiCalling();
    inAsyncCall.value = false;
  }
}
