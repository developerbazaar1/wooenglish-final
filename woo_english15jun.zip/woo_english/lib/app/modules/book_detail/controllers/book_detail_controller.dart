import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:woo_english/app/api/api_constant/api_constant.dart';
import 'package:woo_english/app/api/http_methods/http_methods.dart';
import 'package:woo_english/app/app_controller/app_controller.dart';
import 'package:woo_english/app/common/common_method/common_method.dart';
import 'package:woo_english/app/data/local_database/database_const/database_const.dart';
import 'package:woo_english/app/data/local_database/database_helper/database_helper.dart';
import 'package:woo_english/app/modules/all_reviews/controllers/all_reviews_controller.dart';
import 'package:woo_english/app/modules/all_reviews/views/all_reviews_view.dart';
import 'package:woo_english/app/modules/book_detail/views/book_detail_view.dart';
import 'package:woo_english/app/modules/book_list/controllers/book_list_controller.dart';
import 'package:woo_english/app/modules/book_list/views/book_list_view.dart';
import 'package:woo_english/app/modules/read_book/controllers/read_book_controller.dart';
import 'package:woo_english/app/modules/read_book/views/read_book_view.dart';
import 'package:woo_english/app/modules/video_book/controllers/video_book_controller.dart';
import 'package:woo_english/app/modules/video_book/views/video_book_view.dart';

import '../../../api/api_model/get_dashboard_data_model.dart';

class BookDetailController extends AppController {
  int intValue = 1;
  final count = 0.obs;
  final inAsyncCall = false.obs;
  final isLiked = false.obs;
  final isVideo = true.obs;
  String id = "";
  TextEditingController reviewController = TextEditingController();

  bool like = false;
  String? userName;
  String? userProfile;
  String bookId = "";
  final responseCode = 0.obs;
  Map<String, dynamic> queryParametersForBookDetail = {};
  final getBookDetailDataModel = Rxn<GetDashBoardBooksModel>();
  List<Reviews> reviewsList = [];

  String categoryId = "";
  final responseCodeSimilarBook = 0.obs;
  final getSimilarBookModel = Rxn<GetDashBoardBooksModel>();
  List<Books> bookList = [];
  Map<String, dynamic> queryParametersForSimilarBooks = {};

  Map<String, dynamic> bodyParamsForBookLikeUnlike = {};

  String rating = "1.0";
  Map<String, dynamic> bodyParamsForPostReview = {};


  @override
  void onInit() {
    super.onInit();
    onReload();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  onReload() {
    connectivity.onConnectivityChanged.listen((event) async {
      if (await CM.internetConnectionCheckerMethod()) {
        onInit();
      } else {}
    });
  }

  void increment() => count.value++;

  Future<void> myOnInit() async {
    inAsyncCall.value = true;
    userName = await DatabaseHelper.databaseHelperInstance
            .getParticularData(key: DatabaseConst.columnName) ;
    userProfile = await DatabaseHelper.databaseHelperInstance
            .getParticularData(key: DatabaseConst.columnUserImage) ;
    isLiked.value = like;
    await getBookDetailApiCalling();
    inAsyncCall.value = false;
    await getSimilarBooksApiCalling();
  }

  Future<void> getBookDetailApiCalling() async {
    queryParametersForBookDetail = {ApiKey.bookId: bookId};
    http.Response? response = await HttpMethod.instance.getRequestForParams(
        baseUriForParams: UriConstant.baseUriForParams,
        endPointUri: UriConstant.endPointGetBookDetail,
        queryParameters: queryParametersForBookDetail);
    responseCode.value = response?.statusCode ?? 0;
    queryParametersForBookDetail.clear();
    if (CM.responseCheckForGetMethod(response: response)) {
      getBookDetailDataModel.value =
          GetDashBoardBooksModel.fromJson(jsonDecode(response?.body ?? ""));
      isVideo.value=getBookDetailDataModel.value?.book?.video!=null;
      reviewsList = getBookDetailDataModel.value?.reviews ?? [];
      isLiked.value=getBookDetailDataModel.value?.isFavorite ==1;
    }
  }

  Future<void> getSimilarBooksApiCalling() async {
    queryParametersForSimilarBooks = {
      ApiKey.categoryId: categoryId,
      ApiKey.inBookDetails: "1",
    };
    http.Response? response = await HttpMethod.instance.getRequestForParams(
        baseUriForParams: UriConstant.baseUriForParams,
        endPointUri: UriConstant.endPointGetSimilarBook,
        queryParameters: queryParametersForSimilarBooks);
    responseCodeSimilarBook.value = response?.statusCode ?? 0;
    queryParametersForSimilarBooks.clear();
    if (CM.responseCheckForGetMethod(response: response)) {
      getSimilarBookModel.value =
          GetDashBoardBooksModel.fromJson(jsonDecode(response?.body ?? ""));
      bookList = getSimilarBookModel.value?.books ?? [];
    }
  }

  Future<bool> postReviewApiCalling() async {
    bodyParamsForPostReview = {
      ApiKey.bookId: bookId,
      ApiKey.review: reviewController.text,
      ApiKey.rating: rating,
    };
    http.Response? response = await HttpMethod.instance.postRequest(
        url: UriConstant.endPointPostUserReview,
        bodyParams: bodyParamsForPostReview);
    if (CM.responseCheckForPostMethod(response: response)) {
      bodyParamsForPostReview.clear();
      return true;
    } else {
      bodyParamsForPostReview.clear();
      return false;
    }
  }

  Future<bool> bookLikeUnlikeApiCalling() async {
    bodyParamsForBookLikeUnlike = {
      ApiKey.bookId: bookId,
    };
    http.Response? response = await HttpMethod.instance.postRequest(
        url: UriConstant.endPointAddUserFavorite,
        bodyParams: bodyParamsForBookLikeUnlike);
    if (CM.responseCheckForPostMethod(response: response)) {
      bodyParamsForBookLikeUnlike.clear();
      return true;
    } else {
      bodyParamsForBookLikeUnlike.clear();
      return false;
    }
  }


  void clickOnBackButton() {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    Get.back();
  }

  void clickOnInfoButton() {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  Future<void> clickOnLikeAppBarButton() async {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    if (await bookLikeUnlikeApiCalling()) {
      isLiked.value = !isLiked.value;
    }
    inAsyncCall.value = false;
  }

  void clickOnShareButton() {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  Future<void> clickOnSeeMoreReview() async {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    String tag = CM.getRandomNumber();
    Get.put(AllReviewsController(), tag: tag);
    await Navigator.of(Get.context!).push(
      MaterialPageRoute(
        builder: (context) => AllReviewsView(
          tag: tag,
          bookId: bookId,
        ),
      ),
    );
    await Get.delete<AllReviewsController>(tag: tag);
    inAsyncCall.value = false;
  }

  Future<void> clickOnSubmitButton() async {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    if (reviewController.text.isNotEmpty) {
      if (await postReviewApiCalling()) {
        reviewController.text = "";
        getBookDetailDataModel.value?.reviewCount =
            getBookDetailDataModel.value!.reviewCount! + 1;
      }
    } else {
      CM.showToast("Please write review!");
    }
    inAsyncCall.value = false;
  }

  void onRattingUpdate({required double rating}) {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    this.rating = rating.toString();
    inAsyncCall.value = false;
  }

  Future<void> clickOnSeeMoreBooks({required String id}) async {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    String tag = CM.getRandomNumber();
    Get.put(BookListController(), tag: tag);
    await Navigator.of(Get.context!).push(
      MaterialPageRoute(
        builder: (context) =>
            BookListView(tag: tag, title: id, categoryId: categoryId),
      ),
    );
    await Get.delete<BookListController>(tag: tag);
    inAsyncCall.value = false;
  }

  Future<void> clickOnParticularBookForList({
    required int index,
  }) async {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    String tag = CM.getRandomNumber();
    Get.put(BookDetailController(), tag: tag);
    await Navigator.of(Get.context!).push(
      MaterialPageRoute(
        builder: (context) => BookDetailView(
          tag: tag,
          bookId: bookList[index].id.toString(),
          categoryId: bookList[index].category.toString(),
          isLiked: getSimilarBookModel.value?.favorite
              ?.contains(bookList[index].id.toString()),
        ),
      ),
    );
    await Get.delete<BookDetailController>(tag: tag);
    inAsyncCall.value = false;
  }

  void clickOnSoundButton({required int index}) {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  void clickOnLikeButton({required int index}) {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    inAsyncCall.value = false;
  }

  Future<void> clickOnReadAndListenButton() async {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    String tag = CM.getRandomNumber();
    Get.put(ReadBookController(), tag: tag);
    await Navigator.of(Get.context!).push(
      MaterialPageRoute(
        builder: (context) => ReadBookView(
          tag: tag,
          isLiked: isLiked.value,
          bookId: bookId,
        ),
      ),
    );
    await Get.delete<ReadBookController>(tag: tag);
    await getBookDetailApiCalling();
    inAsyncCall.value = false;
  }

  Future<void> clickOnVideoButton() async {
    CM.unFocsKeyBoard();
    inAsyncCall.value = true;
    String tag = CM.getRandomNumber();
    Get.put(VideoBookController(), tag: tag);
    await Navigator.of(Get.context!).push(
      MaterialPageRoute(
        builder: (context) => VideoBookView(
          tag: tag,
          bookId: bookId,
          categoryId: categoryId,
          isLiked: isLiked.value,
        ),
      ),
    );
    await Get.delete<VideoBookController>(tag: tag);
    await getBookDetailApiCalling();
    inAsyncCall.value = false;
  }
}
